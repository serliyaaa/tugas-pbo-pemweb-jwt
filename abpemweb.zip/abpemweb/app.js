const express = require('express');
const bodyParser = require('body-parser');
const koneksi = require('./config/database');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware Body Parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Create Data (POST)
app.post('/api/latihanrestapii', (req, res) => {
    const data = { ...req.body };
    const querySql = 'INSERT INTO latihanrestapii SET ?';

    koneksi.query(querySql, data, (err, rows, field) => {
        if (err) {
            return res.status(500).json({ message: 'Gagal insert data!', error: err });
        }
        res.status(201).json({ success: true, message: 'Berhasil insert data!' });
    });
});

// Read Data (GET)
app.get('/api/latihanrestapii', (req, res) => {
    const querySql = 'SELECT * FROM latihanrestapii';

    koneksi.query(querySql, (err, rows, field) => {
        if (err) {
            return res.status(500).json({ message: 'Ada kesalahan', error: err });
        }
        res.status(200).json({ success: true, data: rows });
    });
});

// Update Data (PUT)
app.put('/api/latihanrestapii/:id', (req, res) => {
    const data = { ...req.body };
    const querySearch = 'SELECT * FROM latihanrestapii WHERE id = ?';
    const queryUpdate = 'UPDATE latihanrestapii SET ? WHERE id = ?';

    // Jalankan query untuk mencari data
    koneksi.query(querySearch, req.params.id, (err, rows, field) => {
        if (err) {
            return res.status(500).json({ message: 'Ada kesalahan', error: err });
        }

        if (rows.length) {
            // Jika data ditemukan, lakukan update
            koneksi.query(queryUpdate, [data, req.params.id], (err, result, field) => {
                if (err) {
                    return res.status(500).json({ message: 'Gagal update data!', error: err });
                }
                res.status(200).json({ success: true, message: 'Berhasil update data!' });
            });
        } else {
            // Jika data tidak ditemukan
            res.status(404).json({ success: false, message: 'Data tidak ditemukan!' });
        }
    });
});

// Jalankan server
app.listen(PORT, () => console.log(`Server running at port:3000`));
