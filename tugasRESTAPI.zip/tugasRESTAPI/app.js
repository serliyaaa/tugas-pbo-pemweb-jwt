const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');

const app = express();
const PORT = 3000;
const SECRET_KEY = 'mysecretkey'; // Secret key untuk JWT
const tokens = {}; // Penyimpanan token di memori (objek)

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Logging ke file
const accessLogStream = fs.createWriteStream('./access.log', { flags: 'a' });

// Data pengguna (dummy)
const users = require('./data/users.json');

// Endpoint Login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    const user = users.find(u => u.username === username);
    if (!user || !bcrypt.compareSync(password, user.password)) {
        return res.status(401).json({ message: 'Username atau password salah!' });
    }

    const token = jwt.sign({ id: user.id, username: user.username }, SECRET_KEY, { expiresIn: '1h' });

    tokens[token] = 'valid'; // Simpan token di memori
    res.status(200).json({ success: true, token });
});

// Middleware untuk validasi token
const authenticate = (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1];
    if (!token) {
        return res.status(403).json({ message: 'Token diperlukan!' });
    }

    if (tokens[token] !== 'valid') {
        return res.status(403).json({ message: 'Token tidak valid!' });
    }

    try {
        const decoded = jwt.verify(token, SECRET_KEY);
        req.user = decoded;
        next();
    } catch (err) {
        return res.status(403).json({ message: 'Token tidak valid!' });
    }
};

// Endpoint Logout
app.post('/logout', authenticate, (req, res) => {
    const token = req.headers['authorization'].split(' ')[1];
    tokens[token] = 'revoked'; // Tandai token sebagai "revoked"
    res.status(200).json({ message: 'Token berhasil di-revoke!' });
});

// Endpoint untuk mengakses data
app.get('/data', authenticate, (req, res) => {
    const data = [
        { id: 1, name: 'Data Satu' },
        { id: 2, name: 'Data Dua' }
    ];

    const logEntry = `User: ${req.user.username}, Time: ${new Date().toISOString()}, Data Accessed\n`;
    fs.appendFileSync('./access.log', logEntry);

    res.status(200).json({ success: true, data });
});

// Jalankan server
app.listen(PORT, () => console.log(`Server running on http://localhost:3000`));
