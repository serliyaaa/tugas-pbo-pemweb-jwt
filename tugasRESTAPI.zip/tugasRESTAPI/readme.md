# JWT REST API

Proyek ini adalah REST API sederhana yang menggunakan JSON Web Token (JWT) untuk otentikasi dan otorisasi.

## Fitur Utama
1. Login untuk mendapatkan token JWT.
2. Middleware untuk memverifikasi token.
3. Akses data yang dilindungi dengan token.
4. Logout (revoke token).
5. Log akses pengguna.

## Endpoint
### 1. Login
- **URL**: `/login`
- **Method**: `POST`
- **Body**:
  ```json
  {
      "username": "string",
      "password": "string"
  }
